<footer class="site-footer">
  <p>
    © <?php echo date('Y'); ?> Élevage des Vicklands. Tous droits réservés.<br>
    Site conçu par <a href="https://pulsecrea.fr" target="_blank" rel="noopener">PulseCrea</a>
  </p>
</footer>

  <?php wp_footer(); ?>
</body>
</html>
