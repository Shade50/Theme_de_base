<footer>
    <p>&copy; <?php echo date('Y'); ?> PulseCrea. Tous droits réservés.</p>
  </footer>
  <?php wp_footer(); ?>
</body>
</html>
